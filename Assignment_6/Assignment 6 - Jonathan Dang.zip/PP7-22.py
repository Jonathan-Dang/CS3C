#Author: Jonathan Dang
#Assignment: Assignment 6
#Academic Honesty Pledge:
#   This assignment was created and written with my own work
#   and I promise that we held academic integrity at all times during this assignment.
#   If I have been inclined to create something based of off another's work, I will include 
#   specific details pertaining to the assignment within the .py file of each project.
#   I did not seek outside assistance that would violate academic integrity at any point in time, before and to the future
#   of this class.
#   -Jonathan Dang

from sys import argv
#Constants required for this type of solution.
#Keeping the alphabet in the heap would allow me to access it, keeping
#processing simplier.
LOWERCASEALPHA = list("abcdefghijklmnopqrstuvwxyz")
UPPERCASEALPHA = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
DEFAULT_ENCRYPTION_NAME = "Encoded.txt"
DEFAULT_DECRYPTED_NAME = "Decrypted.txt"

def main():
   try:
      decode = False
      key = ""
      files = []
      for arg in argv[1:]:    #Argv is actually an array!, Can use sub-array operator.
         if arg[0] == '-':
            if arg[1] == 'k' or arg[1] == 'K':
               key = arg[2:]
            elif arg[1] == 'd' or arg[1] == 'D':
               decode = True
         else:
            files.append(arg)
         
      #If there is too many files, return
      if len(files) > 2:
         usage()
         return
      #Check to see if there is a key | Return and tell the user to input a key
      if len(key) == 0 or key.isspace():
         usage()
         return
      
      insFile = open(files[0], "r")
      #This block allows for automated file creation upon only given 1 file.
      if len(files) == 1:
         if not decode:
            outsFile = open(DEFAULT_ENCRYPTION_NAME, "w")
         else:
            outsFile = open(DEFAULT_DECRYPTED_NAME,"w")
         print("NO OUTPUT FILE DETECTED, SPAWNING ENCODED/DECODED TEXT FILE.")
      else:
         outsFile = open(files[1],"w")
         
      i = 0
      for line in insFile:
         for char in line:
            outsFile.write(encrypt(char, key[i % (len(key) - 1)], Decode = decode))
            i += 1
   except Exception as e:
      print("Error: " + str(e))
      usage()
      return
   finally:
      insFile.close()
      outsFile.close()
      
      
def usage():
    print("Usage: python encryption.py [-d] -k{key} infile [outfile]")


##
#     Encrypt(ch,key,Decode = False)
#        Input: Character, key, and decode flag
#        Output: A encoded/decoded character
def encrypt(ch, key, Decode = False) :
   LETTERS = 26   # Number of letters in the Roman alphabet.
   
   if not str(ch).isalpha():
      return ch    # Not a letter.

   if ord(ch) > 126:    #Unicode and Ascii are similar enough to detect extended ascii through the use of 126;
      return ch   #Im too lazy to encode extended ascii. Sorry!
   
   if str(key).isupper():
      kOffset = UPPERCASEALPHA.index(key)
   else:
      kOffset = LOWERCASEALPHA.index(key)
      
   if str(ch).isupper():
      base = UPPERCASEALPHA.index(ch)
   else:
      base = LOWERCASEALPHA.index(ch)
   
   if Decode:
      kOffset = -kOffset

   offset = base + kOffset
   if offset >= LETTERS :
      offset = offset - LETTERS
   elif offset < 0 :
      offset = offset + LETTERS 
      
   if str(ch).isupper():
      return UPPERCASEALPHA[offset]
   else:
      return LOWERCASEALPHA[offset]

main()